<?php
//---------------------------
// programmer:	Mahdipour
// create Date:	91.06
//---------------------------
require_once '../../../header.inc.php';  
require_once inc_dataReader;
require_once '../js/confirmation.js.php';

?>
<form id="mainForm">
    <center>
		<br>
		<span>
			<div id="mainpanel"></div>
		</span>
		<br><br>
		<span>
			<div id="docpanel"></div>
		</span>
    </center>    
</form>