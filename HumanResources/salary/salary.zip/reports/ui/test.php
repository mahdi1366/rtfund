﻿<?php

echo iconv("UTF-8", "Windows-1256//TRANSLIT", 'احمد');
	die();	

?>
